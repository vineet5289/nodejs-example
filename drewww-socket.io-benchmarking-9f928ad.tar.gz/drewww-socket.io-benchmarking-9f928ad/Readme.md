# Socket.IO Benchmark

TODO

## How to Install

For server (Node.js) - install it with npm

For client (Java App) - go to the client folder and type 'mvn install'. make sure you install maven before proceed.  

